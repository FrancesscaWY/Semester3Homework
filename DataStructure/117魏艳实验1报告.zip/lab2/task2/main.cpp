#include "company.h"

int main() {
    Company comp;
    comp.inputEmployee();
    comp.inputEmployee();
    comp.inputEmployee();
    comp.inputEmployee();
    comp.inputEmployee();
    comp.findBestPaid();
    comp.printBestPaid();
    return 0;
}